# Requirements

## Operating system

* Windows Vista or
* Windows 7 or
* Windows 8

## 3rd Party Softwares

* A good Codec pack like K-Lite: [http://codecguide.com/download_kl.htm](http://codecguide.com/download_kl.htm) and/or 
* VLC player: [http://www.videolan.org/vlc/index.html](http://www.videolan.org/vlc/index.html) 
