# Developer Guide

## Solution setup

Todo

## Plugins creation

Todo