# Known Issues

* VLC DVD navigation: Next and previous not implemented yet. Users must use the seek bar to navigate chapters.