# Project Description
VR Player is an experimental Virtual Reality Media Player for Head-Mounted Display devices like the Oculus Rift.

**Looking for content?** You can download/stream images and videos from [http://vrplayer.tv](http://vrplayer.tv)

Please support this project by making a donation: 

![Donate](Home_btn_donateCC_LG.gif|https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=stephanelx%40hotmail%2ecom&lc=US&item_name=VR%20Player&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)

or by downloading the Android version:

![Android](Home_en_generic_rgb_wo_45.png|https://play.google.com/store/apps/details?id=com.stephanelx.vrplayer)
# Features

* Read 2D/3D images and videos
* Read local files, streams (including youtube), disc, and more!
* Supported format: mono, over-under, side.
* 3D audio base on orientation and position.
* Preset files to auto-configure application settings

## Available projections:

* Plane (For regular movies projected on a virtual screen)
* Cube (Often used in video games)
* Cylinder (Mainly for panoramic pictures)
* Dome (For action cameras like the go pro)
* Full dome (For imax style experiences)
* Sphere (For 360 videos)
* Custom geometry imported from Maya or 3D Studio (For experimenting with other typologies)

## Available trackers for orientation and position

* mouse
* Oculus Rift
* Wiimote with Motion Plus
* PS Move controller
* Razer Hydra
* Microsoft Kinect
* VRPN client
* Track IR
* LEAP motion
* YEI 3-space.

## Available distortions

* Barrel distortion (Use this one with the Oculus Rift)
* Pincushion distortion

## Effects

* Depth map (over/under or side by side formats)
* Fisheye unwrapping
* Sample filters from the shazzam project
## Preview

{video:url=http://www.youtube.com/watch?v=nRKkstYqHV0,type=youtube}

## Screenshot

![](Home_VrPlayerScreenshot.png)
 
# Chrome extension

This extension finds videos on a web page and provide a link to open them in VR Player:
[https://chrome.google.com/webstore/detail/vr-player-launcher/ajdcpbkfmcceenmocfopaebnnbppkljd](https://chrome.google.com/webstore/detail/vr-player-launcher/ajdcpbkfmcceenmocfopaebnnbppkljd)

# Related links

* MTBS3D forum: [http://www.mtbs3d.com/phpbb/viewtopic.php?f=140&t=15927](http://www.mtbs3d.com/phpbb/viewtopic.php?f=140&t=15927)
* Oculus forum: [https://developer.oculusvr.com/forums/viewtopic.php?f=29&t=112](https://developer.oculusvr.com/forums/viewtopic.php?f=29&t=112)
* Oculus subreddit: [http://www.reddit.com/r/oculus/](http://www.reddit.com/r/oculus/)