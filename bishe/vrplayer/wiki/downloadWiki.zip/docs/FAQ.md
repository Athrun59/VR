# FAQ

## How to use a camera or a TV capture device

# Download and install VLC
# Open VLC and go to "Media->Open capture device.."
# Set capture mode to Directshow and select your camera or other capture device in the drop down list
# Click on the "Show more options" check box
# Copy the MRL (Media url) link and paste to VR Player using "File->Open->Stream->With VLC"

## Where can I get content

You can visit [http://vrplayer.tv](http://vrplayer.tv)


