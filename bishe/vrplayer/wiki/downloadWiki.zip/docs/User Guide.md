# Inputs

## Keyboard shortcuts

* ESC: Exit full screen
* Arrows + Page up/dpwn: Move camera
* Space: Play/Pause

## Input devices calibration

* All trackers: Press "F1" ("F2" to reset)
* Nintendo Wiimote: Press "+"
* Playstation Move: Press "Start"
* Razer Hydra: Press the oval button under the analog stick. 
* Microsoft Kinect: Rise your right hand above your head