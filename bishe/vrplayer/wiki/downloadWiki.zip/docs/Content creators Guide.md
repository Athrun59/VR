# Content creators Guide

## Embeding XMP metadata

# Download source code and keep only the "Xmp" folder
# From this folder, copy "VrPlayer" folder and all its content to adobe custom panel folder. (Example: C:\Program Files (x86)\Common Files\Adobe\XMP\Custom File Info Panels\3.0\panels\)
# Open Adobe bridge and select your media
# Right click and select "File Info..."
# Go to VR Player panel and paste content of a .json preset file
# Click Ok and save

![](Content creators Guide_VrPlayerPanelForAdobeBridge.png)