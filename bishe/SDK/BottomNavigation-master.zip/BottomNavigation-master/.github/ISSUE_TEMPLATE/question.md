---
name: Question
about: Questions about the library

---

## Question
<!--- Have you gone though the wiki? Put an `x` in all the boxes that apply: -->
- [ ] Wiki Home (https://github.com/Ashok-Varma/BottomNavigation/wiki)
- [ ] Customisations (https://github.com/Ashok-Varma/BottomNavigation/wiki/Customisations)
- [ ] Behaviour and Animations (https://github.com/Ashok-Varma/BottomNavigation/wiki/Behaviour-and-Animations-Settings)
- [ ] Badges (https://github.com/Ashok-Varma/BottomNavigation/wiki/Badges)
- [ ] Fab & SnackBar (https://github.com/Ashok-Varma/BottomNavigation/wiki/FAB-&-SnackBar)

- [ ] None of those answer my question
