package com.asha.vrlib.plugins.hotspot;

import android.view.ViewGroup;

/**
 * Created by hzqiujiadi on 2017/4/12.
 * hzqiujiadi ashqalcn@gmail.com
 */

public class MDLayoutParams extends ViewGroup.LayoutParams {

    public MDLayoutParams(int width, int height) {
        super(width, height);
    }

    public MDLayoutParams(ViewGroup.LayoutParams source) {
        super(source);
    }
}
