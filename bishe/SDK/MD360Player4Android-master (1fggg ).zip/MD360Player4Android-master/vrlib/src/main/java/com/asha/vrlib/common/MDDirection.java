package com.asha.vrlib.common;

/**
 * Created by hzqiujiadi on 16/9/28.
 * hzqiujiadi ashqalcn@gmail.com
 */

public enum MDDirection {
    HORIZONTAL, VERTICAL
}
