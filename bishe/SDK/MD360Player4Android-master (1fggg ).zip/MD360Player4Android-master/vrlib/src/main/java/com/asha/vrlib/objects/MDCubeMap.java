package com.asha.vrlib.objects;

public class MDCubeMap extends MDSphere3D {
}

