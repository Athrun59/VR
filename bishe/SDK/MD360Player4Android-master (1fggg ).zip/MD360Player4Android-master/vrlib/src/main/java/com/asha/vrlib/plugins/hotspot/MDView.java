package com.asha.vrlib.plugins.hotspot;

import com.asha.vrlib.model.MDViewBuilder;

/**
 * Created by hzqiujiadi on 2017/4/13.
 * hzqiujiadi ashqalcn@gmail.com
 */

public class MDView extends MDAbsView {

    public MDView(MDViewBuilder builder) {
        super(builder);
    }
}
