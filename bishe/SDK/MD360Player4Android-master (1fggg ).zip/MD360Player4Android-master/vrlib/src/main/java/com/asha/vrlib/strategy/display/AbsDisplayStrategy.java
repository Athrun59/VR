package com.asha.vrlib.strategy.display;

import android.content.Context;

import com.asha.vrlib.strategy.IModeStrategy;

/**
 * Created by hzqiujiadi on 16/3/19.
 * hzqiujiadi ashqalcn@gmail.com
 */
public abstract class AbsDisplayStrategy implements IModeStrategy,IDisplayMode {

    @Override
    public void onResume(Context context) {

    }

    @Override
    public void onPause(Context context) {

    }
}
