package com.martin.ads.vrlib.constant;

/**
 * Created by Ads on 2017/2/10.
 */

public class AdjustingMode {
    public static final int ADJUSTING_MODE_STRETCH=1;
    public static final int ADJUSTING_MODE_CROP=2;
    public static final int ADJUSTING_MODE_FIT_TO_SCREEN=3;

}
