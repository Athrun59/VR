package com.martin.ads.vrlib.filters.vr;

import com.martin.ads.vrlib.filters.base.AbsFilter;

/**
 * Created by Ads on 2017/3/11.
 */

@Deprecated
//If you need support for skybox/cubic, please open an issue.
public class SkyBox extends AbsFilter {
    @Override
    public void init() {

    }

    @Override
    public void destroy() {

    }

    @Override
    public void onDrawFrame(int textureId) {

    }
}
