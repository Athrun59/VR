package com.martin.ads.vrlib.constant;

/**
 * Created by Ads on 2016/6/25.
 */
public enum PanoMode
{
    MOTION,TOUCH,SINGLE_SCREEN,DUAL_SCREEN
}