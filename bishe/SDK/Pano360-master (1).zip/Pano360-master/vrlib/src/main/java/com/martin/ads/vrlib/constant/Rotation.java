package com.martin.ads.vrlib.constant;

/**
 * Created by Ads on 2016/11/19.
 */

public enum Rotation {
    NORMAL, ROTATION_90, ROTATION_180, ROTATION_270
}
