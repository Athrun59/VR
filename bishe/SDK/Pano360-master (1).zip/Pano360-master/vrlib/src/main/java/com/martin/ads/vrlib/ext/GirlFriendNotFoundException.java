package com.martin.ads.vrlib.ext;

/**
 * Created by Ads on 2016/8/16.
 */

public class GirlFriendNotFoundException extends IllegalStateException {
    public GirlFriendNotFoundException() {
        super("Miss YSJ,I want nothing but you.");
    }
}
