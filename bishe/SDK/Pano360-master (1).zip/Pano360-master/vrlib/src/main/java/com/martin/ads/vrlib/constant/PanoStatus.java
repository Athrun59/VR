package com.martin.ads.vrlib.constant;

/**
 * Created by Ads on 2016/6/25.
 */
public enum PanoStatus
{
    IDLE, PREPARED,BUFFERING, PLAYING, PAUSED_BY_USER, PAUSED, STOPPED, COMPLETE, ERROR
}

