package com.nbsp.materialfilepicker;

import org.junit.Test;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class BuilderTest {
    @Test
    public void getIntent() {
    }
}